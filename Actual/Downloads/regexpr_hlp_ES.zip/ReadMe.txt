Spanish help for TRegExpr.

Just extract *.cnt and *.hlp files from this archive 
into Help\ subfolder of TRegExpr intallation directory.
