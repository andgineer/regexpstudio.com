#include <stdlib.h>

void __stdcall (* errproc)(char *) = NULL;

void
regerror(char *s)
{
#ifdef ERRAVAIL
	error("regexp: %s", s);
#else
   if (errproc)
     errproc(s);
#endif
	/* NOTREACHED */
}

void _export __stdcall
registerregerrproc(void __stdcall (*f)(char *))
{
  errproc = f;
};


