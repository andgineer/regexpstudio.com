---------------------------------------------------------------
TGREP v1.0 beta

Author:
  Gabriele Carioli 
  Viale Antonio Gramsci, 102
  47100 Forl� (FO) - ITALY
  E-mail: bilo@lingue.unibo.it
---------------------------------------------------------------
This component is a "wrapper" of a regular expression library 
I found somewhere (see "Legal Issues"). I adapted the sources
to be compiled with Borland C++ v5.0 and made up a 32bit DLL.

To install the component copy:

  RegExpForm.pas
  RegExpForm.dfm
  Grep.pas
  Grep.dcr

in your component directory, and place regexp.dll both in the
Delphi 3\bin directory and in your project directory (or just 
in the windows\system directory if you like it).  Then you've 
to add GREP.PAS to your VCL.   Remember to distribute the DLL
with your applications. 
Supported regular expressions are e-grep like (give a look at
"regexp.doc" for details).


property RegExp: string; 
  Set and read the regular expression

property Text: string;
  Text to be parsed

function Grep: boolean;  
  Perform the parsing: returns true if regexp is found,
  false otherwise.  Iterate until false to find all the
  occurrences.

property Found: boolean;
  True if last grep was successful, false otherwise.

procedure Split(max: integer; elems: TStrings);
  This is a Delphi implementation of the Perl "split"
  operator. Tokenizes Text using RegExp as separator.
  Tokens are put in "elems". The first "max" elements
  are found (all if max=0). See example (Project2).

function Subst(s: string): string;
  See example (Project1);

property SubExp[index: TSubExpRange]: TSubRegExp;
  This is a default property array. It consists of the 
  RegExp subexpressions (at most 9) found in Text.

    SubExp[0] is & (the **whole** expression)
    SubExp[1] is \1 (the 1st subexpression)
    ...
    SubExp[9] is \9 (the 9st subexpression)    

  Each element has these properties:

    SubExp[n].StartP: integer; 
      Start index of \n within parsed text
    SubExp[n].EndP: integer;
      End index of \n within parsed text
    SubExp[n].Text: string;
      The subexpression;

  See example (Project1) and sources (Grep.pas)


Any bug report, comments, ideas, are appreciated.
A translation of the C source into Pascal would be even more
appreciated :o) 

---------------------------------------------------------------
Legal issues
---------------------------------------------------------------

Legal issues for the Delphi part:

* Copyright � 1997-98 by Gabriele Carioli <bilo@lingue.unibo.it>
* 
* This software is provided as it is, without any kind of warranty
* given. Use it at your own risk.
* 
* You may use this software in any kind of development, including
* comercial, redistribute, and modify it freely, under the 
* following restrictions :
* 
* 1. The origin of this software may not be mispresented, you must
*    not claim that you wrote the original software. If you use
*    this software in any kind of product, it would be appreciated
*    that there in a information box, or in the documentation would
*    be an acknowledgmnent like this
*           Parts Copyright � 1998 by Gabriele Carioli
* 
* 2. You may not have any income from distributing this source
*    to other developers. When you use this product in a comercial
*    package, the source may not be charged seperatly.
* 
* 3. This notice should also follow the package if you use this
*    component in a commercial product.

Legal issues for the C part:

*  Copyright (c) 1986 by University of Toronto.
*  Written by Henry Spencer.  Not derived from licensed software.
*
*  Permission is granted to anyone to use this software for any
*  purpose on any computer system, and to redistribute it freely,
*  subject to the following restrictions:
*
*  1. The author is not responsible for the consequences of use of
*      this software, no matter how awful, even if they arise
*      from defects in it.
*
*  2. The origin of this software must not be misrepresented, either
*      by explicit claim or by omission.
*
*  3. Altered versions must be plainly marked as such, and must not
*      be misrepresented as being the original software.
*
* Beware that some of this code is subtly aware of the way operator
* precedence is structured in regular expressions.  Serious changes in
* regular-expression syntax might require a total rethink.
