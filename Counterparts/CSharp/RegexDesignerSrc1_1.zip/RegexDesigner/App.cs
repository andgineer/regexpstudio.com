using System;
using System.Resources;
using System.Reflection;

/// <summary>
/// Summary description for App.
/// </summary>
internal class App
{
	static App()
	{
	    // Load (cache) application-wide data
        ResourceManager   rm = new ResourceManager("App", Assembly.GetExecutingAssembly());
        _applicationName = rm.GetString("ApplicationName");
    }
    
    public static string ApplicationName
    {
        get { return _applicationName; }
    }		

    static string   _applicationName;
}
