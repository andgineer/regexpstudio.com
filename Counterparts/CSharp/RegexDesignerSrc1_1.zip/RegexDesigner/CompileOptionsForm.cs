using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Reflection;

public class CompileOptionsForm : System.Windows.Forms.Form
{
    private System.Windows.Forms.GroupBox groupBox1;
    public  System.Windows.Forms.TextBox txtFileName;
    private System.Windows.Forms.Button cmdBrowse;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    public  System.Windows.Forms.ComboBox listProtection;
    public  System.Windows.Forms.TextBox txtClass;
    public  System.Windows.Forms.TextBox txtNamespace;
    private System.Windows.Forms.SaveFileDialog saveAssemblyDialog;
    private System.Windows.Forms.Button cmdOK;
    private System.Windows.Forms.Button cmdCancel;
    private System.Windows.Forms.ErrorProvider errorProvider;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public CompileOptionsForm()
	{
		//
		// Required for Windows Form Designer support
		//
		InitializeComponent();

		//
		// TODO: Add any constructor code after InitializeComponent call
		//
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
        this.label1 = new System.Windows.Forms.Label();
        this.txtFileName = new System.Windows.Forms.TextBox();
        this.label3 = new System.Windows.Forms.Label();
        this.saveAssemblyDialog = new System.Windows.Forms.SaveFileDialog();
        this.cmdCancel = new System.Windows.Forms.Button();
        this.listProtection = new System.Windows.Forms.ComboBox();
        this.cmdOK = new System.Windows.Forms.Button();
        this.txtNamespace = new System.Windows.Forms.TextBox();
        this.label2 = new System.Windows.Forms.Label();
        this.txtClass = new System.Windows.Forms.TextBox();
        this.cmdBrowse = new System.Windows.Forms.Button();
        this.groupBox2 = new System.Windows.Forms.GroupBox();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.errorProvider = new System.Windows.Forms.ErrorProvider();
        this.groupBox2.SuspendLayout();
        this.groupBox1.SuspendLayout();
        this.SuspendLayout();
        // 
        // label1
        // 
        this.label1.Location = new System.Drawing.Point(8, 24);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(72, 23);
        this.label1.TabIndex = 4;
        this.label1.Text = "&Namespace:";
        // 
        // txtFileName
        // 
        this.txtFileName.Location = new System.Drawing.Point(12, 24);
        this.txtFileName.Name = "txtFileName";
        this.txtFileName.Size = new System.Drawing.Size(364, 20);
        this.txtFileName.TabIndex = 1;
        this.txtFileName.Text = "MyRegexFileName.dll";
        this.txtFileName.Validating += new System.ComponentModel.CancelEventHandler(this.txtFileName_Validating);
        // 
        // label3
        // 
        this.label3.Location = new System.Drawing.Point(8, 72);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(72, 23);
        this.label3.TabIndex = 8;
        this.label3.Text = "&Protection:";
        // 
        // saveAssemblyDialog
        // 
        this.saveAssemblyDialog.DefaultExt = "dll";
        this.saveAssemblyDialog.FileName = "regex";
        this.saveAssemblyDialog.Filter = "Assemblies (*.dll)|*.dll";
        // 
        // cmdCancel
        // 
        this.cmdCancel.CausesValidation = false;
        this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
        this.cmdCancel.Location = new System.Drawing.Point(372, 201);
        this.cmdCancel.Name = "cmdCancel";
        this.cmdCancel.TabIndex = 11;
        this.cmdCancel.Text = "Cancel";
        this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
        // 
        // listProtection
        // 
        this.listProtection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.listProtection.DropDownWidth = 121;
        this.listProtection.Items.AddRange(new object[] {
                                                            "Private",
                                                            "Public"});
        this.listProtection.Location = new System.Drawing.Point(88, 72);
        this.listProtection.Name = "listProtection";
        this.listProtection.Size = new System.Drawing.Size(121, 21);
        this.listProtection.TabIndex = 9;
        // 
        // cmdOK
        // 
        this.cmdOK.DialogResult = System.Windows.Forms.DialogResult.OK;
        this.cmdOK.Location = new System.Drawing.Point(285, 201);
        this.cmdOK.Name = "cmdOK";
        this.cmdOK.TabIndex = 10;
        this.cmdOK.Text = "OK";
        this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
        // 
        // txtNamespace
        // 
        this.txtNamespace.Location = new System.Drawing.Point(88, 24);
        this.txtNamespace.Name = "txtNamespace";
        this.txtNamespace.Size = new System.Drawing.Size(288, 20);
        this.txtNamespace.TabIndex = 5;
        this.txtNamespace.Text = "MyRegexNamespace";
        this.txtNamespace.Validating += new System.ComponentModel.CancelEventHandler(this.txtNamespace_Validating);
        // 
        // label2
        // 
        this.label2.Location = new System.Drawing.Point(8, 48);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(72, 23);
        this.label2.TabIndex = 6;
        this.label2.Text = "&Class:";
        // 
        // txtClass
        // 
        this.txtClass.Location = new System.Drawing.Point(88, 48);
        this.txtClass.Name = "txtClass";
        this.txtClass.Size = new System.Drawing.Size(288, 20);
        this.txtClass.TabIndex = 7;
        this.txtClass.Text = "MyRegexClass";
        this.txtClass.Validating += new System.ComponentModel.CancelEventHandler(this.txtClass_Validating);
        // 
        // cmdBrowse
        // 
        this.cmdBrowse.Location = new System.Drawing.Point(400, 24);
        this.cmdBrowse.Name = "cmdBrowse";
        this.cmdBrowse.Size = new System.Drawing.Size(24, 20);
        this.cmdBrowse.TabIndex = 2;
        this.cmdBrowse.Text = "...";
        this.cmdBrowse.Click += new System.EventHandler(this.cmdBrowse_Click);
        // 
        // groupBox2
        // 
        this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                this.listProtection,
                                                                                this.txtNamespace,
                                                                                this.label1,
                                                                                this.label2,
                                                                                this.label3,
                                                                                this.txtClass});
        this.groupBox2.Location = new System.Drawing.Point(13, 81);
        this.groupBox2.Name = "groupBox2";
        this.groupBox2.Size = new System.Drawing.Size(435, 108);
        this.groupBox2.TabIndex = 3;
        this.groupBox2.TabStop = false;
        this.groupBox2.Text = "&Type";
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                this.cmdBrowse,
                                                                                this.txtFileName});
        this.groupBox1.Location = new System.Drawing.Point(13, 9);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Size = new System.Drawing.Size(435, 60);
        this.groupBox1.TabIndex = 0;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "&Assembly File Name";
        // 
        // CompileOptionsForm
        // 
        this.AcceptButton = this.cmdOK;
        this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
        this.CancelButton = this.cmdCancel;
        this.ClientSize = new System.Drawing.Size(462, 239);
        this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                      this.cmdCancel,
                                                                      this.cmdOK,
                                                                      this.groupBox2,
                                                                      this.groupBox1});
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
        this.MaximizeBox = false;
        this.MinimizeBox = false;
        this.Name = "CompileOptionsForm";
        this.ShowInTaskbar = false;
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
        this.Text = "Compile Assembly Options";
        this.Load += new System.EventHandler(this.CompileOptionsForm_Load);
        this.groupBox2.ResumeLayout(false);
        this.groupBox1.ResumeLayout(false);
        this.ResumeLayout(false);

    }
	#endregion
    
    #region Event Handlers
    private void cmdBrowse_Click(object sender, System.EventArgs e)
    {
        saveAssemblyDialog.FileName = txtFileName.Text;
        if( saveAssemblyDialog.ShowDialog() != DialogResult.OK ) return;
        txtFileName.Text = saveAssemblyDialog.FileName;
    }

    private void cmdOK_Click(object sender, System.EventArgs e)
    {
        // Validate controls by setting focus to them
        bool   valid = true;
        foreach( Control control in Controls )
        {
            control.Focus();
            if( !Validate() ) valid = false;
        }
        if( valid ) Close();
    }
    
    private void cmdCancel_Click(object sender, System.EventArgs e)
    {
        Close();
    }    

    private void txtFileName_Validating(object sender, System.ComponentModel.CancelEventArgs e)
    {
        string   error = "";
            
        // Check assembly file name has been entered
        string   assemFileName = Path.GetFileName(txtFileName.Text);
        if( assemFileName == "" )
        {
            error = "FileName can't be empty.";
            e.Cancel = true;
            errorProvider.SetError(txtFileName, error);
            return;
        }
        
        // Check that folder is valid
        string   assemDir = Path.GetDirectoryName(txtFileName.Text);
        if(assemDir != "")
        {
            if( !Directory.Exists(assemDir) )
            {   
                error = string.Format("Folder {0} does not exist.", assemDir);
                e.Cancel = true;
                errorProvider.SetError(txtFileName, error);
                return;
            }
        }
        errorProvider.SetError(txtFileName, error);
    }

    private void txtNamespace_Validating(object sender, System.ComponentModel.CancelEventArgs e)
    {
        // Check Namespace name
        string   error = "";
        Regex    reNamespace = new Regex(@"^(([a-zA-Z])(\.?[a-zA-Z][a-zA-Z0-9]*)*)$");
        if( !reNamespace.IsMatch(txtNamespace.Text) )
        {
            error = "Please provide a valid Namespace name.";
            e.Cancel = true;
        }
        errorProvider.SetError(txtNamespace, error);
    }

    private void txtClass_Validating(object sender, System.ComponentModel.CancelEventArgs e)
    {
        // Check Class name
        string   error = "";
        Regex    reClass = new Regex(@"^[a-zA-Z][a-zA-Z0-9]*$");
        if( !reClass.IsMatch(txtClass.Text) )
        {
            error = "Please provide a valid class name.";
            e.Cancel = true;
        }
        errorProvider.SetError(txtClass, error);
    }

    private void CompileOptionsForm_Load(object sender, System.EventArgs e)
    {
        // Select first control on the form
        txtFileName.SelectAll();
        txtFileName.Focus();
    }
    #endregion
}