using System;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Reflection;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Resources;

public class GenerateCodeDialog : System.Windows.Forms.Form
{
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Panel panel4;
    private System.Windows.Forms.Button cmdCopy;
    private System.Windows.Forms.Button cmdClose;
    private System.Windows.Forms.TextBox txtCode;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public RegexOptions Options;
    public string       Expression = "";
    public string       Input = "";
    public string       Replacement = "";
    public string       Split = "";

    private XsltCodeGenerator.Input[]   _csInputs;
    private XsltCodeGenerator.Input[]   _vbInputs;
	private System.Windows.Forms.ComboBox cboOperation;
	private System.Windows.Forms.ComboBox cboLanguage;
    
    private int   _controlMargin = 8;		

    private static string[] _possibleOperations = null;
    private System.Windows.Forms.Label lblOperation;
    private System.Windows.Forms.Label lblLanguage;
    private static string[] _possibleLanguages = null;

	static GenerateCodeDialog()
	{
        string[] tmp = Enum.GetNames( typeof( Operation ) );
        _possibleOperations = new string[ tmp.Length -1 ];
        Array.Copy( tmp, 1, _possibleOperations, 0, _possibleOperations.Length );

        _possibleLanguages = Enum.GetNames( typeof( Language ) );
	}    

    public GenerateCodeDialog()
    {
        // Required for Windows Form Designer support
        InitializeComponent();
    }

    protected string EncodeNonPrintingCS(string s)
    {
        // TODO: What have I missed?
        return s.Replace("\"", "\"\"").Replace("\r\n", "\" + \"\\r\\n\" + @\"").Replace("\r", "\" + \"\\r\" + @\"").Replace("\n", "\" + \"\\n\" + @\"").Replace("\t", "\" + \"\\t\" + @\"");
    }

    protected string EncodeNonPrintingVB(string s)
    {
        // TODO: What have I missed?
        return s.Replace("\"","\"\"").Replace("\r\n", "\" &amp; Chr(10) &amp; Chr(13) &amp; \"").Replace("\r", "\" &amp; Chr(10) &amp; \"").Replace("\n", "\" &amp; Chr(13) &amp; \"").Replace("\t", "\" &amp; Chr(9) &amp; \"");
    }

    protected override void OnLoad(EventArgs e)
    {
        // Let the base class have its way
        base.OnLoad(e);

        // Set up options
        StringBuilder   options = new StringBuilder();
        foreach( string option in Options.ToString().Split(',') )
        {
            if( options.Length > 0 ) options.Append(" OR ");
            options.Append("RegexOptions.").Append(option.Trim());
        }

        //TODO: Check later (MW Temp Build)

        // Set up inputs
        _csInputs = new XsltCodeGenerator.Input[]
        {
            new XsltCodeGenerator.Input("options",      options.ToString().Replace("OR", "|")),
            new XsltCodeGenerator.Input("expression",   EncodeNonPrintingCS(Expression)),
            new XsltCodeGenerator.Input("input",        Input.Replace("\"", "\"\"")),
            new XsltCodeGenerator.Input("replacement",  EncodeNonPrintingCS(Replacement)),
            new XsltCodeGenerator.Input("split",        EncodeNonPrintingCS(Split)),
            
        };

        _vbInputs = new XsltCodeGenerator.Input[]
        {
            new XsltCodeGenerator.Input("options",      options.ToString().Replace("OR", "Or")),
            new XsltCodeGenerator.Input("expression",   EncodeNonPrintingVB(Expression)),
            new XsltCodeGenerator.Input("input",        Input.Replace("\"", "\"\"")),
            new XsltCodeGenerator.Input("replacement",  EncodeNonPrintingVB(Replacement)),
            new XsltCodeGenerator.Input("split",        EncodeNonPrintingVB(Split)),
        };

        cboOperation.SuspendLayout();        
        cboLanguage.SuspendLayout();

        // populate and then select index 0 for the comboboxes
        cboOperation.Items.AddRange( _possibleOperations );
        cboLanguage.Items.AddRange( _possibleLanguages );
        cboOperation.SelectedIndex = 0;
        cboLanguage.SelectedIndex = 0;

        // add the eventhandlers after the index has been 
        // selected to prevent errors in UiGenerateCode
        cboOperation.SelectedIndexChanged += new System.EventHandler(this.cboGeneric_SelectedIndexChanged);
        cboLanguage.SelectedIndexChanged += new System.EventHandler(this.cboGeneric_SelectedIndexChanged);

        cboOperation.ResumeLayout();
        cboLanguage.ResumeLayout();

        // Show code
        UiGenerateCode();
    }

    protected override void OnResize(EventArgs e)
    {
        // Let the base class have its way
        base.OnResize(e);
        
        // Move buttons accordingly
        cmdClose.Left = panel4.Width - _controlMargin - cmdClose.Width;
        cmdClose.Top = panel4.Height - _controlMargin - cmdClose.Height;
        cmdCopy.Left = cmdClose.Left - _controlMargin - cmdCopy.Width;
        cmdCopy.Top = cmdClose.Top;
    }
    
    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing )
    {
        if( disposing )
        {
            if(components != null)
            {
                components.Dispose();
            }
        }
        base.Dispose( disposing );
    }

//    enum Operation
//    {
//        Match,
//        Replace,
//        Split,
//    }

    enum Language
    {
        CSharp,
        VB,
    }

    string GenerateCode(Operation op, Language lang)
    {
        string              resName = "RegexDesigner.Exemplars." + op.ToString() + lang.ToString() + ".xslt";
        string              template = "";
        using( Stream       stream = GetType().Assembly.GetManifestResourceStream(resName) )
        using( StreamReader reader = new StreamReader(stream) )
        {
            template = reader.ReadToEnd();
        }

        return XsltCodeGenerator.Generate(template, (lang == Language.CSharp ? _csInputs : _vbInputs));
    }

	#region Windows Form Designer generated code
/// <summary>
/// Required method for Designer support - do not modify
/// the contents of this method with the code editor.
/// </summary>
private void InitializeComponent()
{
    System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(GenerateCodeDialog));
    this.panel1 = new System.Windows.Forms.Panel();
    this.lblLanguage = new System.Windows.Forms.Label();
    this.lblOperation = new System.Windows.Forms.Label();
    this.cboLanguage = new System.Windows.Forms.ComboBox();
    this.cboOperation = new System.Windows.Forms.ComboBox();
    this.panel4 = new System.Windows.Forms.Panel();
    this.cmdClose = new System.Windows.Forms.Button();
    this.cmdCopy = new System.Windows.Forms.Button();
    this.txtCode = new System.Windows.Forms.TextBox();
    this.panel1.SuspendLayout();
    this.panel4.SuspendLayout();
    this.SuspendLayout();
    // 
    // panel1
    // 
    this.panel1.Controls.Add(this.lblLanguage);
    this.panel1.Controls.Add(this.lblOperation);
    this.panel1.Controls.Add(this.cboLanguage);
    this.panel1.Controls.Add(this.cboOperation);
    this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
    this.panel1.Location = new System.Drawing.Point(0, 0);
    this.panel1.Name = "panel1";
    this.panel1.Size = new System.Drawing.Size(560, 56);
    this.panel1.TabIndex = 2;
    // 
    // lblLanguage
    // 
    this.lblLanguage.Location = new System.Drawing.Point(152, 8);
    this.lblLanguage.Name = "lblLanguage";
    this.lblLanguage.Size = new System.Drawing.Size(100, 16);
    this.lblLanguage.TabIndex = 3;
    this.lblLanguage.Text = "Language:";
    // 
    // lblOperation
    // 
    this.lblOperation.Location = new System.Drawing.Point(8, 8);
    this.lblOperation.Name = "lblOperation";
    this.lblOperation.Size = new System.Drawing.Size(100, 16);
    this.lblOperation.TabIndex = 2;
    this.lblOperation.Text = "Operation:";
    // 
    // cboLanguage
    // 
    this.cboLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
    this.cboLanguage.Location = new System.Drawing.Point(152, 24);
    this.cboLanguage.Name = "cboLanguage";
    this.cboLanguage.Size = new System.Drawing.Size(136, 21);
    this.cboLanguage.TabIndex = 1;
    // 
    // cboOperation
    // 
    this.cboOperation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
    this.cboOperation.Location = new System.Drawing.Point(8, 24);
    this.cboOperation.Name = "cboOperation";
    this.cboOperation.Size = new System.Drawing.Size(136, 21);
    this.cboOperation.TabIndex = 0;
    // 
    // panel4
    // 
    this.panel4.Controls.Add(this.cmdClose);
    this.panel4.Controls.Add(this.cmdCopy);
    this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
    this.panel4.Location = new System.Drawing.Point(0, 342);
    this.panel4.Name = "panel4";
    this.panel4.Size = new System.Drawing.Size(560, 40);
    this.panel4.TabIndex = 3;
    // 
    // cmdClose
    // 
    this.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
    this.cmdClose.Location = new System.Drawing.Point(476, 9);
    this.cmdClose.Name = "cmdClose";
    this.cmdClose.TabIndex = 1;
    this.cmdClose.Text = "Close";
    this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
    // 
    // cmdCopy
    // 
    this.cmdCopy.Location = new System.Drawing.Point(392, 9);
    this.cmdCopy.Name = "cmdCopy";
    this.cmdCopy.TabIndex = 0;
    this.cmdCopy.Text = "Copy";
    this.cmdCopy.Click += new System.EventHandler(this.cmdCopy_Click);
    // 
    // txtCode
    // 
    this.txtCode.Dock = System.Windows.Forms.DockStyle.Fill;
    this.txtCode.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
    this.txtCode.Location = new System.Drawing.Point(0, 56);
    this.txtCode.Multiline = true;
    this.txtCode.Name = "txtCode";
    this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.Both;
    this.txtCode.Size = new System.Drawing.Size(560, 286);
    this.txtCode.TabIndex = 4;
    this.txtCode.Text = "";
    this.txtCode.WordWrap = false;
    // 
    // GenerateCodeDialog
    // 
    this.AcceptButton = this.cmdCopy;
    this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
    this.CancelButton = this.cmdClose;
    this.ClientSize = new System.Drawing.Size(560, 382);
    this.Controls.Add(this.txtCode);
    this.Controls.Add(this.panel4);
    this.Controls.Add(this.panel1);
    this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
    this.MinimumSize = new System.Drawing.Size(400, 400);
    this.Name = "GenerateCodeDialog";
    this.ShowInTaskbar = false;
    this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
    this.Text = "Generate Code";
    this.panel1.ResumeLayout(false);
    this.panel4.ResumeLayout(false);
    this.ResumeLayout(false);

}
	#endregion

    #region Event Handlers
    void UiGenerateCode()
    {
        Operation   op = (Operation)cboOperation.SelectedIndex + 1;
        Language    lang = (Language)cboLanguage.SelectedIndex;
        txtCode.Text = GenerateCode(op, lang);
    }    

    private void cmdClose_Click(object sender, System.EventArgs e)
    {
        Close();
    }

    private void cmdCopy_Click(object sender, System.EventArgs e)
    {
        // Copy to clipboard
        Clipboard.SetDataObject(txtCode.Text, true);
        MessageBox.Show("Code copied to Clipboard", App.ApplicationName);
    }
   
    private void cboGeneric_SelectedIndexChanged(object sender, System.EventArgs e)
    {
        UiGenerateCode();
    }

    #endregion	        
}