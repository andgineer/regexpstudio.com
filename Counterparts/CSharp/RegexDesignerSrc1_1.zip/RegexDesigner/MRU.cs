// MRU.cs: Contributed by Michael Weinhardt[mikedub@bigpond.com]
// An MRU file menu helper -- see the sample for usage
#region Copyright � 2002 The Genghis Group
/*
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the authors be held liable for any damages arising from the
 * use of this software.
 * 
 * Permission is granted to anyone to use this software for any purpose,
 * including commercial applications, subject to the following restrictions:
 * 
 * 1. The origin of this software must not be misrepresented; you must not claim
 * that you wrote the original software. If you use this software in a product,
 * an acknowledgment in the product documentation is IsRequired, as shown here:
 * 
 * Portions copyright � 2002 The Genghis Group (http://www.genghisgroup.com/).
 * 
 * 2. No substantial portion of the source code of this library may be redistributed
 * without the express written permission of the copyright holders, where
 * "substantial" is defined as enough code to be recognizably from this library. 
*/
#endregion

#region TODOs

// TODO: Apply C# commenting: http://www.gotdotnet.com/team/csharp/Information/Whitepapers/XMLDocs.doc
// TODO: Add exceptions (arguments in resource file)
// TODO: Resource strings for exceptions
// TODO: Optional separator bars above and below MRU menu
// TODO: Optional default text ie if empty, parent MRU menu item is not visible
// TODO: Provide different constructors to support optional properties, such as default text

#endregion

#region QUESTIONs

// QUESTION: Handle file storage too (Isolated Storage)?
// QUESTION: Should menuItemClickEventHandler be optional?
// QUESTION: Should MRUStringCollection become generic MRUCollection (array storage) with specific MRUFilenameCollection wrapper?
// QUESTION: If no to previous question, should MRUStringCollection be private?
// QUESTION: Make formattedFilePathWidth dynamic, rather than set-once in constructor?

#endregion

#region Basic Design

// NOTE: The basic design is broken down into three layers:
//       1) Storage: MRUStringCollection
//       2) Glue   : InMenuMRUHelper, SubMenuMRUHelper (IMRUHelper)
//       3) Client Access and Extensibility Point: MRU (IMRUHelper)
//
//       Storage) is responsible for applying MRU mechanics on a collection of strings
//
//       Glue   ) uses the string collection as filename storage and merges it with the associated 
//                InMenu or SubMenu menu items, inluding path truncation and numeric access keys
//
//       Access ) instantiated and accessed from client code, providing a thin polymorphic wrapper
//                over 1 or more IMRUHelpers

#endregion

using System;
using System.Collections.Specialized;    // StringCollection
using System.Windows.Forms;              // MenuItem
using System.Text;                       // StringBuilder
using System.Collections;                // IEnumerator

namespace Genghis.Windows.Forms
{
    public enum MRUMenuLocation
    {
        InMenu = 1,
        InSubMenu = 2
    }
  
    public class MRU : IMRUHelper
    {	
        public MRU(MRUMenuLocation mruMenuLocation, int maxItems, string defaultMenuText, int formattedFilePathWidth, MenuItem parent, EventHandler menuItemClickEventHandler)
        {
            switch( mruMenuLocation )
            {
                case MRUMenuLocation.InMenu:
                    _mruHelper = new InMenuMRUHelper(maxItems, defaultMenuText, formattedFilePathWidth, parent, menuItemClickEventHandler);
                    break;
                    
                case MRUMenuLocation.InSubMenu:
                    _mruHelper = new InSubMenuMRUHelper(maxItems, defaultMenuText, formattedFilePathWidth, parent, menuItemClickEventHandler);
                    break;
            }
        }
        
        #region IMRUHelper
        
        public int Count
        {
            get { return _mruHelper.Count; }
        }
        
        public string GetFileName(int menuItemIndex)
        {
            return _mruHelper.GetFileName(menuItemIndex);
        }
        
        public string DefaultMenuText
        {
            get { return _mruHelper.DefaultMenuText; }
        }
        
        public void Add(string mruFileName)
        {
            _mruHelper.Add(mruFileName);
        }
        
        public void Clear()
        {
            _mruHelper.Clear();
        }
        
        public MenuItem Parent
        {
            get { return _mruHelper.Parent; }
        }
        
        public int Capacity
        {
            get { return _mruHelper.Capacity; }
            set { _mruHelper.Capacity = value; }
        }
        
        public int FormattedFilePathWidth
        {
            get { return _mruHelper.FormattedFilePathWidth; }
            set { _mruHelper.FormattedFilePathWidth = value; }
        }        
        
        #endregion
        
        IMRUHelper   _mruHelper;
    }
  
    internal class InMenuMRUHelper : IMRUHelper
    {
        public InMenuMRUHelper(int maxItems, string defaultMenuText, int formattedFilePathWidth, MenuItem parent, EventHandler menuItemClickEventHandler)
        {
            // Check arguments are valid
            if( maxItems < 0 ) throw new ArgumentOutOfRangeException();
            if( defaultMenuText == null ) throw new ArgumentNullException();
            if( menuItemClickEventHandler == null ) throw new ArgumentNullException();
            if( parent == null ) throw new ArgumentNullException();
            if( parent.Parent == null ) throw new ArgumentNullException();
	    
            // Set values
            _menuItemsCount = 0;
            _defaultMenuText = defaultMenuText;
            _formattedFilePathWidth = formattedFilePathWidth;
            _parent = parent;
            _menuItemClickEventHandler = menuItemClickEventHandler;
            _maxItems = maxItems;
            _mruFileList = new MRUStringCollection(_maxItems);
            
            // Display default menu item
            DisplayDefaultMenuItem();
        }
        
        public int Count
        {
            get { return _menuItemsCount ; }
        }

        public int Capacity
        {
            get { return _mruFileList.Capacity; }
            set
            {
                _mruFileList.Capacity = value;
                if( _mruFileList.Count > 0 ) Resequence();
            }
        }
        
        public string DefaultMenuText
        {
            get { return _defaultMenuText; }
        }
        
        public int FormattedFilePathWidth
        {
            get { return _formattedFilePathWidth; }
            set { _formattedFilePathWidth = value; }
        }
        
        public string GetFileName(int menuItemIndex)
        {
            // Check argument is valid
            if( (menuItemIndex <= _parent.Index) || (menuItemIndex > _parent.Index + _mruFileList.Count) ) throw new ArgumentOutOfRangeException();
        
            // Get filename
            return _mruFileList[menuItemIndex - _parent.Index - 1];
        }

        public void Add(string mruFileName)
        {
            _mruFileList.Add(mruFileName.ToLower());
            Resequence();
        }
        
        public void Clear()
        {
            // Clear menu items and menu collection
            ClearMenuItems();
            DisplayDefaultMenuItem();
            _mruFileList = new MRUStringCollection(_maxItems);
            _menuItemsCount = 0;
        }

        public MenuItem Parent
        {
            get { return _parent; }
        }
        
        private void MenuItemClickEventHandler(object sender, System.EventArgs e)
        {
            MenuItem   mi = (MenuItem) sender;
            // NOTE: This check is required if a Resequence occurred before this event was called
            //       This can happen if the client Click event attached to the menu item is called
            //       and proceeds to cause an activity which results in an Add and Resequence.  Therefore
            //       this menu item becomes invalid ie loses it's parent and has it's index set to -1 
            //       before it get's here
            // TODO: How do I do this better???
            if( mi.Parent != null ) Add(GetFileName(mi.Index));
        }
        
        private void Resequence()
        {
            // Clear menu items
            ClearMenuItems();
        
            // Fill MRU menu
            _parent.Enabled = true;
            _parent.Visible = false;
            int   menuPosition = 0;
            foreach( string mruFileName in _mruFileList )
            {
                // TODO: Use a counter or a for loop for navigating the collection
                //       (foreach is the preferred mechanism)
                menuPosition++;
                string     formattedAccessKey = MenuFormatter.FormatAccessKey(menuPosition);
                string     formattedFilePath = MenuFormatter.FormatFilePath(mruFileName, _formattedFilePathWidth);
                MenuItem   mi = new MenuItem(formattedAccessKey + " " + formattedFilePath, _menuItemClickEventHandler);
                mi.Click += new System.EventHandler(MenuItemClickEventHandler);
                _parent.Parent.MenuItems.Add(_parent.Index + menuPosition, mi);
            }
        
            // Get num of items in menu
            _menuItemsCount = _mruFileList.Count;
        }
        
        private void ClearMenuItems()
        {
            // Clear menu items only, not menu collection
            Menu.MenuItemCollection   menuInsertLocation = _parent.Parent.MenuItems;
            for( int menuItemIndex = 1; menuItemIndex <= _menuItemsCount; menuItemIndex++ )
            {
                menuInsertLocation.Remove(menuInsertLocation[_parent.Index + 1]);
            }
        }
        
        private void DisplayDefaultMenuItem()
        {
            // Display default menu item
            _parent.Text = _defaultMenuText;
            _parent.Enabled = false;
            _parent.Visible = true;
        }
        
        private int                   _menuItemsCount;
        private string                _defaultMenuText;
        private int                   _formattedFilePathWidth;
        private MRUStringCollection   _mruFileList;
        private EventHandler          _menuItemClickEventHandler;
        private MenuItem              _parent;
        private int                   _maxItems;
    } 

    internal class InSubMenuMRUHelper : IMRUHelper
    {
        public InSubMenuMRUHelper(int maxItems, string defaultMenuText, int formattedFilePathWidth, MenuItem parent, EventHandler menuItemClickEventHandler)
        {
            // Check arguments are valid
            if( maxItems < 0 ) throw new ArgumentOutOfRangeException();
            if( defaultMenuText == null ) throw new ArgumentNullException();
            if( menuItemClickEventHandler == null ) throw new ArgumentNullException();
            if( parent == null ) throw new ArgumentNullException();
	    
            // Set values
            _menuItemsCount = 0;
            _defaultMenuText = defaultMenuText;
            _formattedFilePathWidth = formattedFilePathWidth;
            _menuItemClickEventHandler = menuItemClickEventHandler;
            _parent = parent;
            _maxItems = maxItems;
            _mruFileList = new MRUStringCollection(_maxItems);
            
            // Display default menu item
            DisplayDefaultMenuItem();
        }
        
        public int Count
        {
            get { return _menuItemsCount ; }
        }

        public int Capacity
        {
            get { return _mruFileList.Capacity; }
            set
            {
                _mruFileList.Capacity = value;
                if( _mruFileList.Count > 0 ) Resequence();
            }
        }

        public string DefaultMenuText
        {
            get { return _defaultMenuText; }
        }
                
        public int FormattedFilePathWidth
        {
            get { return _formattedFilePathWidth; }
            set { _formattedFilePathWidth = value; }
        }
        
        public string GetFileName(int index)
        {
            // Check arguments are valid
            if( (index < 0) || (index >= _mruFileList.Count) ) throw new ArgumentOutOfRangeException();
        
            // Get filename
            return _mruFileList[index];
        }

        public void Add(string mruFileName)
        {
            _mruFileList.Add(mruFileName.ToLower());
            Resequence();
        }
        
        public void Clear()
        {
            // Clear menu items and menu collection
            _parent.MenuItems.Clear();
            DisplayDefaultMenuItem();
            _mruFileList = new MRUStringCollection(_maxItems);
            _menuItemsCount = 0;
        }

        public MenuItem Parent
        {
            get { return _parent; }
        }
        
        private void MenuItemClickEventHandler(object sender, System.EventArgs e)
        {
            MenuItem   mi = (MenuItem) sender;
            // NOTE: This check is required if a Resequence occurred before this event was called
            //       This can happen if the client Click event attached to the menu item is called
            //       and proceeds to cause an activity which results in an Add and Resequence.  Therefore
            //       this menu item becomes invalid ie loses it's parent and has it's index set to -1 
            //       before it get's here
            // TODO: How do I do this better???
            if( mi.Parent != null ) Add(GetFileName(mi.Index));
        }
        
        private void Resequence()
        {
            // Clear existing submenu
            _parent.MenuItems.Clear();

            // Fill and resequence submenu
            _parent.Enabled = true;
            foreach( string mruFileName in _mruFileList )
            {
                string     formattedAccessKey = MenuFormatter.FormatAccessKey(_parent.MenuItems.Count + 1);
                string     formattedFilePath = MenuFormatter.FormatFilePath(mruFileName, _formattedFilePathWidth);
                MenuItem   mi = new MenuItem(formattedAccessKey + " " + formattedFilePath, _menuItemClickEventHandler);
                mi.Click += new System.EventHandler(MenuItemClickEventHandler);
                _parent.MenuItems.Add(_parent.MenuItems.Count, mi);
            }
                    
            // Get num of items in menu
            _menuItemsCount = _mruFileList.Count;
        }
        
        private void DisplayDefaultMenuItem()
        {
            // Display default menu item
            _parent.Text = _defaultMenuText;
            _parent.Enabled = false;
            _parent.Visible = true;
        }
        
        private int                   _menuItemsCount;
        private string                _defaultMenuText;
        private int                   _formattedFilePathWidth;
        private MRUStringCollection   _mruFileList;
        private EventHandler          _menuItemClickEventHandler;
        private MenuItem              _parent;
        private int                   _maxItems;
    } 

    internal interface IMRUHelper
    {
        int Count
        {
            get;
        }
        string DefaultMenuText
        {
            get;
        }
        string GetFileName(int menuItemIndex);
        void Add(string mruFileName);
        void Clear();
        int Capacity
        {
            get;
            set;
        }
        int FormattedFilePathWidth
        {
            get;
            set;
        }        
        MenuItem Parent
        {
            get;
        }
    }
        
    internal class MenuFormatter
    {
        public static string FormatAccessKey(int listPosition)
        {
            // Build numeric access key
            if( listPosition <= 9 ) return string.Format("&{0}", listPosition);
            else if( listPosition == 10 ) return "1&0";
            else return listPosition.ToString();
        }
        
        /// <summary>
        /// Produces display friendly short filename.
        /// </summary>
        /// <param name="FileNameWithPath">Filename with path to shrink.</param>
        /// <param name="maxLength">Maximum length to use.</param>
        /// <returns>Short filename.</returns>
        /// <credit>Altered slightly from original post by James Berry from the win_tech_off_topic list</credit>
        public static string FormatFilePath(string fileNameWithPath, int maxLength)
        {        
            // We will begin by taking the string and splitting it apart into an array
            // Check if we are within the max length then return the whole string
            if( fileNameWithPath.Length <= maxLength ) return fileNameWithPath;

            // Split the string into an array using the \ as a delimiter
            char[]     seperator = {'\\'};
            string[]   pathBits;
            pathBits = fileNameWithPath.Split(seperator);

            // The first value of the array is taken in case we need to create the string
            StringBuilder   sb = new StringBuilder();
            int             length = sb.Length;
            int             beginLength = pathBits[0].Length + 3;
            bool            addHeader = false;
            string          pathItem;
            int             pathItemLength;

            // Now we loop backwards through the string
            for( int pathItemIndex = pathBits.Length - 1; pathItemIndex > 0; pathItemIndex-- ) 
            {
                pathItem = '\\' + pathBits[pathItemIndex];
                pathItemLength = pathItem.Length;

                // Check if adding the current item does not increase the length of the 
                // max string
                if( length + pathItemLength <= maxLength )
                {
                    // In this case we can afford to add the item
                    sb.Insert(0, pathItem);
                    length += pathItemLength;
                }
                else break;

                // Check if there is room to add the header and if so then reserve it by 
                // incrementing the length
                if( (addHeader == false) && (length + beginLength <= maxLength) )
                {
                    addHeader = true;
                    length += beginLength;
                }
            }

            // It is possible that the last value in the array itself was long
            // In such case simply use the substring of the last value
            if( sb.Length == 0 ) return pathBits[pathBits.Length - 1].Substring(0, maxLength);

            // Add the header if the bool is true
            if( addHeader == true ) sb.Insert(0, pathBits[0] + "\\...");	        
            return sb.ToString();
        }
    }
    
    public class MRUStringCollection : IList
    {
        public MRUStringCollection()
        {
            _capacity = int.MaxValue;
            _mruStringCollection = new StringCollection();
        }
        
        public MRUStringCollection(int maxItems)
        {
            _capacity = maxItems;
            _mruStringCollection = new StringCollection();
        }
        
        #region ICollection
        
        public int Count
        {
            get { return _mruStringCollection.Count; }
        }
    
        public void CopyTo(Array array, int index)
        {
            string[]   tmpArray = new string[0];
            _mruStringCollection.CopyTo(tmpArray, index);
            array = tmpArray;
        }
    
        public bool IsSynchronized
        {
            get { return false; }
        }
    
        public MRUStringCollection SyncRoot
        {
            get { return null; }
        }
        
        int ICollection.Count
        {
            get { return Count; }
        }
        
        void ICollection.CopyTo(Array array, int index)
        {
            CopyTo(array, index);
        }
        
        bool ICollection.IsSynchronized
        {
            get { return IsSynchronized; }
        }

        object ICollection.SyncRoot
        {
            get { return SyncRoot; }
        }
        
        #endregion
        
        #region IEnumerable
        
        public IEnumerator GetEnumerator()
        {
            return new MRUStringCollectionEnumerator(_mruStringCollection);
        }
        
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        
        #endregion
        
        #region IEnumerator
        
        public class MRUStringCollectionEnumerator : IEnumerator
        {
            public MRUStringCollectionEnumerator(StringCollection mruStringCollection)
            {
                _mruStringCollection = mruStringCollection;
                Reset();
            }
        
            public string Current
            {
                get
                {
                    // If the enumerator points to an element, return it
                    if( (_mruStringIndex < 0) || (_mruStringIndex > _mruStringCollection.Count - 1) ) throw new InvalidOperationException();
                    return _mruStringCollection[_mruStringIndex];
                }
            }
        
            public bool MoveNext()
            {
                // Move enumerator to next element
                return( ++_mruStringIndex < _mruStringCollection.Count );
            }
        
            public void Reset()
            {
                // Move enumerator to beginning of the collection, before the first element
                _mruStringIndex = -1;
            }

            object IEnumerator.Current
            {
                get { return Current; }
            }
            
            bool IEnumerator.MoveNext()
            {
                return MoveNext();
            }
            
            void IEnumerator.Reset()
            {
                Reset();
            }
            
            int                _mruStringIndex;
            StringCollection   _mruStringCollection;
        }
        
        #endregion

        #region IList
        
        public int Add(string value)
        {
            // Don't do anything if this file is the first item
            if( IndexOf(value) == 0 ) return -1;
        
            // Move file to top if already in the list, unless it's the first item
            string   newValue = value;
            int      valueIndex = IndexOf(value);
            if( valueIndex > 0 )
            {
                newValue = this[valueIndex];
                RemoveAt(valueIndex);
            }

            // Insert new item at top
            Insert(0, value);

            // Remove superfluous 
            if( _capacity < Count ) TrimToSize();
            
            return 0;
        }
                
        public void Clear()
        {
            _mruStringCollection.Clear();
        }
        public bool Contains(string value)
        {
            return _mruStringCollection.Contains(value);
        }
        
        public int IndexOf(string value)
        {
            return _mruStringCollection.IndexOf(value);
        }
                
        public void Insert(int index, string value)
        {
            _mruStringCollection.Insert(index, value);
        }
        
        public bool IsFixedSize
        {
            get { return false; }
        }
        
        public bool IsReadOnly
        {
            get { return false; }
        }
        
        public void Remove(string value)
        {
            _mruStringCollection.Remove(value);
        }
        
        public void RemoveAt(int index)
        {
            _mruStringCollection.RemoveAt(index);
        }
        
        public string this[int index]
        {
            get { return _mruStringCollection[index]; }
            set { _mruStringCollection[index] = value;}
        }
        
        
        int IList.Add(object value)
        {
            return Add((string) value);
        }
        
        void IList.Clear()
        {
            Clear();
        }
        
        bool IList.Contains(object value)
        {
            return Contains((string) value);
        }
        
        int IList.IndexOf(object value)
        {
            return IndexOf((string) value);
        }
        
        void IList.Insert(int index, object value)
        {
            Insert(index, (string) value);
        }
        
        bool IList.IsFixedSize
        {
            get { return IsFixedSize; }
        }
        
        bool IList.IsReadOnly
        {
            get { return IsReadOnly; }
        }
        
        void IList.Remove(object value)
        {
            Remove((string) value);
        }
        
        void IList.RemoveAt(int index)
        {
            RemoveAt(index);
        }
        
        object IList.this[int index]
        {
            get { return this[index]; }
            set { this[index] = (string) value;}
        }
        
        #endregion
        
        public int Capacity
        {
            get { return _capacity; }
            set
            { 
                if( value < 0 ) throw new ArgumentOutOfRangeException("capacity");
                _capacity = value;
                if( _capacity < Count ) TrimToSize();
            }
        }
        
        private void TrimToSize()
        {
            for( int i = Count - 1; i >= _capacity ; i-- )
            {
                RemoveAt(_capacity);
            }
        }

        int                _capacity;
        StringCollection   _mruStringCollection;
    }
 }