// RegexDoc.cs

using System;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using System.Reflection;    // AssemblyName
using System.IO;    // Path

[Serializable]
internal class RegexDoc : ISerializable, IDeserializationCallback
{
    public RegexDoc()
    {
    }

    public string Expression
    {
        get { return _regex; }
        set { _regex = value; Dirty = true; }
    }

    public string Text
    {
        get { return _text; }
        set { _text = value; Dirty = true; }
    }

    public string Replacement
    {
        get { return _replace; }
        set { _replace = value; Dirty = true; }
    }

    public RegexOptions Options
    {
        get { return _options; }
        set { _options = value; Dirty = true; }
    }

    public bool Option(RegexOptions option)
    {
        return (_options & option) != 0;
    }
    
    public string AssemblyFileName
    {
        get { return _assemblyFileName; }
        set { _assemblyFileName = value; Dirty = true; }
    }

    public string AssemblyNamespace
    {
        get { return _assemblyNamespace; }
        set { _assemblyNamespace = value; Dirty = true; }
    }

    public string AssemblyClass
    {
        get { return _assemblyClass; }
        set { _assemblyClass = value; Dirty = true; }
    }

    public bool AssemblyClassPublic
    {
        get { return _assemblyClassPublic; }
        set { _assemblyClassPublic = value; Dirty = true; }
    }

    public SegmentCollection MatchAndSegmentRegex(bool processMultiple)
    {
        return new SegmentCollection(Operation.Match, _text, _regex, null, _options, processMultiple);
    }

    public SegmentCollection ReplaceAndSegmentRegex(bool processMultiple)
    {
        return new SegmentCollection(Operation.Replace, _text, _regex, _replace, _options, processMultiple);
    }
        
    public SegmentCollection SplitAndSegmentRegex(bool processMultiple)
    {
        return new SegmentCollection(Operation.Split, _text, _regex, "|", _options, processMultiple);
    }

    public MatchCollection MatchRegex()
    {
        Regex   re = new Regex(_regex, _options);
        return re.Matches(_text);
    }

    public bool Compile()
    {
        AssemblyName   assemName = new AssemblyName();
        assemName.Name = Path.GetFileNameWithoutExtension(this.AssemblyFileName);

        RegexCompilationInfo   info = new RegexCompilationInfo(_regex, _options, _assemblyClass, _assemblyNamespace, _assemblyClassPublic);
        Regex.CompileToAssembly(new RegexCompilationInfo[] { info }, assemName);
        return true;
    }

    public bool Dirty
    {
        get { return _dirty; }
        set { _dirty = value; }
    }
    public bool ReadOnly
    {
        get { return _readOnly; }
        set { _readOnly = value; }
    }
    
    // ISerializable
    protected RegexDoc(SerializationInfo info, StreamingContext context)
    {
        string  serialVersion = info.GetString("_serialVersion");
        switch( serialVersion )
        {
                // NOTE: We're leaving _processMultiple as _matchMultiple in the serialization
                // format to maintain backwards compatibility with older files.
            case "1.0":
                // 1.0 fields
                _regex = info.GetString("_regex");
                _text = info.GetString("_text");
                _options = (RegexOptions)info.GetValue("_options", typeof(RegexOptions));
                _processMultiple = info.GetBoolean("_matchMultiple");

                // New 1.1 fields
                _assemblyFileName = "";
                _assemblyNamespace = "";
                _assemblyClass = "";
                _assemblyClassPublic = true;

                // New 1.2 fields
                _replace = "";
                break;

            case "1.1":
                // 1.1 fields
                _regex = info.GetString("_regex");
                _text = info.GetString("_text");
                _options = (RegexOptions)info.GetValue("_options", typeof(RegexOptions));
                _processMultiple = info.GetBoolean("_matchMultiple");
                _assemblyFileName = info.GetString("_assemblyFileName");
                _assemblyNamespace = info.GetString("_assemblyNamespace");
                _assemblyClass = info.GetString("_assemblyClass");
                _assemblyClassPublic = info.GetBoolean("_assemblyClassPublic");

                // New 1.2 fields
                _replace = "";
                break;

            case "1.2":
                // 1.2 fields
                _regex = info.GetString("_regex");
                _text = info.GetString("_text");
                _options = (RegexOptions)info.GetValue("_options", typeof(RegexOptions));
                _processMultiple = info.GetBoolean("_matchMultiple");
                _assemblyFileName = info.GetString("_assemblyFileName");
                _assemblyNamespace = info.GetString("_assemblyNamespace");
                _assemblyClass = info.GetString("_assemblyClass");
                _assemblyClassPublic = info.GetBoolean("_assemblyClassPublic");
                _replace = info.GetString("_replace");
                break;

            case "1.3":
                // 1.3 fields
                _regex = info.GetString("_regex");
                _text = info.GetString("_text");
                _options = (RegexOptions)info.GetValue("_options", typeof(RegexOptions));
                // Removed _processMultiple - now an app-wide UI option (see MainForm.cs)
                _assemblyFileName = info.GetString("_assemblyFileName");
                _assemblyNamespace = info.GetString("_assemblyNamespace");
                _assemblyClass = info.GetString("_assemblyClass");
                _assemblyClassPublic = info.GetBoolean("_assemblyClassPublic");
                _replace = info.GetString("_replace");
                break;
                        
            default:
                throw new SerializationException("Unknown file version: " + serialVersion);
        }
    }
    
    public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
    {
        // NOTE: We're leaving _processMultiple as _matchMultiple in the serialization
        // format to maintain backwards compatibility with older files.

        info.AddValue("_serialVersion", _serialVersion);
        info.AddValue("_regex", _regex);
        info.AddValue("_text", _text);
        info.AddValue("_options", _options);
        info.AddValue("_matchMultiple", _processMultiple);
        info.AddValue("_assemblyFileName", _assemblyFileName);
        info.AddValue("_assemblyNamespace", _assemblyNamespace);
        info.AddValue("_assemblyClass", _assemblyClass);
        info.AddValue("_assemblyClassPublic", _assemblyClassPublic);
        info.AddValue("_replace", _replace);
    }

    // IDeserializationCallback
    public void OnDeserialization(object sender)
    {
        _dirty = false;
    }

    private const string    _serialVersion = "1.3";

    // 1.0 fields
    private string          _regex;
    private string          _text;
    private RegexOptions    _options = RegexOptions.None;
    // _processMultiple not used in v1.3, but kept for backward compatibility
    private bool            _processMultiple = true;

    // 1.1 additional fields
    private string          _assemblyFileName;
    private string          _assemblyNamespace;
    private string          _assemblyClass;
    private bool            _assemblyClassPublic = true;

    // 1.2 additional fields
    private string          _replace = "";

    // [NonSerialized]
    private bool            _dirty = false;
    private bool            _readOnly = false;
}
