using System;
using System.Windows.Forms;

internal class TabMsgFilter: IMessageFilter
{
	private const int WM_KEYDOWN = 0x0100;
	private const int WM_KEYUP   = 0x0101;

	private const int VK_TAB     = 0x0009;
	private const int VK_SHIFT   = 0x0010;
	private const int VK_CONTROL = 0x0011;

	private TabControl _tab;
	private bool _ctrl;
	private bool _shift;

	public TabMsgFilter(TabControl tabControl)
	{
		_tab = tabControl;
	}

	public bool PreFilterMessage(ref Message m)
	{
		if (m.Msg == WM_KEYDOWN)
		{
			if ((int)m.WParam == VK_CONTROL) 
			{
				_ctrl = true;
				return false;
			}
			else if ((int)m.WParam == VK_SHIFT) 
			{
				_shift = true;
				return false;
			}

			if (_ctrl && (int)m.WParam == VK_TAB && _tab.ContainsFocus)
			{
				if (_shift)	//prev tab
				{
					if (_tab.SelectedIndex > 0)
						_tab.SelectedIndex--;
					else
						_tab.SelectedIndex = _tab.TabPages.Count - 1;
				}
				else //next tab
				{
					if (_tab.SelectedIndex < _tab.TabPages.Count - 1)
						_tab.SelectedIndex++;
					else
						_tab.SelectedIndex = 0;
				}

				return true;
			}
		}
		else if (m.Msg == WM_KEYUP)
		{
			if ((int)m.WParam == VK_CONTROL)
			{
				_ctrl = false;
				return false;
			}
			else if ((int)m.WParam == VK_SHIFT)
			{
				_shift = false;
				return false;
			}
		}

		return false;
	}
}
