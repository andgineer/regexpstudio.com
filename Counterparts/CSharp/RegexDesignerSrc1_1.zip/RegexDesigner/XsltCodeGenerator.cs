// XsltCodeGenerator.cs
using System;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

// Usage:
/*
 * <!-- greeting.xsl -->
 * <xsl:transform version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
 *  <xsl:output method="text"/>
 *  <xsl:template match="/">
 * Console.WriteLine("<xsl:value-of select="/input/greeting" />");
 *  </xsl:template>
 * </xsl:transform>
 * 
 * string                    template = (new StreamReader("greeting.xsl")).ReadToEnd();
 * XsltCodeGenerator.Input[] inputs = { new XsltCodeGenerator.Input("greeting", "Hi!") };
 * string code = XsltCodeGenerator.Generate(template, inputs);
*/
public class XsltCodeGenerator
{
    public class Input
    {
        public string   Name;
        public object   Value;

        public Input(string name, object value) { Name = name; Value = value; }
    }

    public static string Encode(string s)
    {
        // Protect < and > from the XSLT processor
        return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
    }

    public static string Generate(string template, Input[] inputs)
    {
        // Build input XML
        StringBuilder   sb = new StringBuilder();
        sb.Append("<input>");
        foreach( Input input in inputs )
        {
            sb.Append(Environment.NewLine);
            sb.Append("<").Append(input.Name).Append(">");
            sb.Append(Encode(input.Value.ToString()));
            sb.Append("</").Append(input.Name).Append(">");
        }
        sb.Append(Environment.NewLine).Append("</input>");

        // Generate code from XSLT template
        using( Stream xsltStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(template)) )
        using( Stream xmlStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(sb.ToString())) )
        {
            XslTransform    transform = new XslTransform();
            transform.Load(new XmlTextReader(xsltStream), null, null );

            XPathDocument   doc = new XPathDocument(xmlStream);
            StringWriter    writer = new StringWriter();
            transform.Transform(doc, null, writer, null );

            return writer.ToString().Trim();
        }
    }
}

